package com.nttdata.proyecto01Culqui.business;

import com.nttdata.proyecto01Culqui.model.ClienteRequest;
import com.nttdata.proyecto01Culqui.model.ClienteResponse;
import com.nttdata.proyecto01Culqui.model.entity.Cliente;
import com.nttdata.proyecto01Culqui.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClienteServiceImp implements ClienteService {

    @Autowired
    ClienteRepository clienteRepository;

    @Autowired
    ClienteMapper clienteMapper;

    @Override
    public List<ClienteResponse> listarClientes() {
        return clienteRepository.findAll().stream()
                .map(m->clienteMapper.getClienteResponse(m))
                .collect(Collectors.toList());
    }

    @Override
    public ClienteResponse registrarClientes(ClienteRequest clienteRequest) {
        return clienteMapper
                .getClienteResponse(clienteRepository.
                        save(clienteMapper.getClienteEntity(clienteRequest)));
    }
}

