package com.nttdata.proyecto02Culqui.business;

import com.nttdata.proyecto02Culqui.model.CuentaRequest;
import com.nttdata.proyecto02Culqui.model.CuentaResponse;
import com.nttdata.proyecto02Culqui.model.entity.Cuenta;
import org.springframework.stereotype.Component;

@Component
public class CuentaMapper {
    public Cuenta getCuentaEntity(CuentaRequest request){
        Cuenta entity= new Cuenta();
        entity.setNumeroCuenta(request.getNumeroCuenta());
        entity.setTipoCuenta(request.getTipoCuenta());
        entity.setSaldo(request.getSaldo());
        entity.setClienteId(request.getClienteId());
        return entity;
    }

    public CuentaResponse CuentaResponse(Cuenta entity){
        CuentaResponse response= new CuentaResponse();
        response.setNumeroCuenta(entity.getNumeroCuenta());
        response.setTipoCuenta(entity.getTipoCuenta());
        response.setSaldo(entity.getSaldo());
        response.setClienteId(entity.getClienteId());
        return response;
    }

}
