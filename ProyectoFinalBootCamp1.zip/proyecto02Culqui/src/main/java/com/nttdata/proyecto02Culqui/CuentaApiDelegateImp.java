package com.nttdata.proyecto02Culqui;

import com.nttdata.proyecto02Culqui.api.CuentaApiDelegate;
import com.nttdata.proyecto02Culqui.business.CuentaService;
import com.nttdata.proyecto02Culqui.model.CuentaRequest;
import com.nttdata.proyecto02Culqui.model.CuentaResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CuentaApiDelegateImp implements CuentaApiDelegate {

    @Autowired
    CuentaService cuentaService;

    @Override
    public ResponseEntity<List<CuentaResponse>> listarCuentas() {
        return ResponseEntity.ok(cuentaService.listarCuentas());
    }

    @Override
    public ResponseEntity<CuentaResponse> registrarCuentas(CuentaRequest cuentaRequest) {
        return ResponseEntity.ok(cuentaService.registrarCuentas(cuentaRequest));
    }

}
