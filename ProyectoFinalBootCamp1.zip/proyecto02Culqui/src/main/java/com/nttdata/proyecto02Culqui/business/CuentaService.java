package com.nttdata.proyecto02Culqui.business;

import com.nttdata.proyecto02Culqui.model.CuentaRequest;
import com.nttdata.proyecto02Culqui.model.CuentaResponse;

import java.util.List;

public interface CuentaService {

    public List<CuentaResponse> listarCuentas();

    public CuentaResponse registrarCuentas(CuentaRequest cuentaRequest);
}
