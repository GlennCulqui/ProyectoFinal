package com.nttdata.proyecto01Culqui;

import com.nttdata.proyecto01Culqui.api.ClienteApiDelegate;
import com.nttdata.proyecto01Culqui.business.ClienteService;
import com.nttdata.proyecto01Culqui.model.ClienteRequest;
import com.nttdata.proyecto01Culqui.model.ClienteResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ClienteApiDelegateImp implements ClienteApiDelegate {

    @Autowired
    ClienteService clienteService;


    @Override
    public ResponseEntity<List<ClienteResponse>> listarClientes() {
        return ResponseEntity.ok(clienteService.listarClientes());
    }

    @Override
    public ResponseEntity<ClienteResponse> registrarClientes(ClienteRequest clienteRequest) {
        return ResponseEntity.ok(clienteService.registrarClientes(clienteRequest));
    }
}
