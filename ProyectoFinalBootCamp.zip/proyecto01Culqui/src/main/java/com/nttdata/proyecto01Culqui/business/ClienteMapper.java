package com.nttdata.proyecto01Culqui.business;

import com.nttdata.proyecto01Culqui.model.ClienteRequest;
import com.nttdata.proyecto01Culqui.model.ClienteResponse;
import com.nttdata.proyecto01Culqui.model.entity.Cliente;
import org.springframework.stereotype.Component;

@Component
public class ClienteMapper {

    public Cliente getClienteEntity(ClienteRequest request){
        Cliente entity = new Cliente();
        entity.setDni(request.getDni());
        entity.setNombre(request.getNombre());
        entity.setApellido(request.getApellido());
        entity.setEmail(request.getEmail());
        return entity;
    }

    public ClienteResponse getClienteResponse(Cliente entity){
        ClienteResponse response= new ClienteResponse();
        response.setDni(entity.getDni());
        response.setNombre(entity.getNombre());
        response.setApellido(entity.getApellido());
        response.setEmail(entity.getEmail());
        return response;
    }

}
