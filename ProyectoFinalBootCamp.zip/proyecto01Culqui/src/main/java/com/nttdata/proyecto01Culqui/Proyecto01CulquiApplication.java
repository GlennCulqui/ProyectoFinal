package com.nttdata.proyecto01Culqui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto01CulquiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto01CulquiApplication.class, args);
	}

}
