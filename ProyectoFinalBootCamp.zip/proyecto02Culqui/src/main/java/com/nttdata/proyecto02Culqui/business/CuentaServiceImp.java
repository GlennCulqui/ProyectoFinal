package com.nttdata.proyecto02Culqui.business;

import com.nttdata.proyecto02Culqui.model.CuentaRequest;
import com.nttdata.proyecto02Culqui.model.CuentaResponse;
import com.nttdata.proyecto02Culqui.repository.CuentaRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

public class CuentaServiceImp implements CuentaService{


    @Autowired
    CuentaRepository cuentaRepository;

    @Autowired
    CuentaMapper cuentaMapper;

    @Override
    public List<CuentaResponse> listarCuentas() {
        return cuentaRepository.findAll().stream()
                .map(m->cuentaMapper)
    }

    @Override
    public CuentaResponse registrarCuentas(CuentaRequest cuentaRequest) {
        return null;
    }
}
