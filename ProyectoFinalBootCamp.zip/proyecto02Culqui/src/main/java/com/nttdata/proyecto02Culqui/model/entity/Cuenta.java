package com.nttdata.proyecto02Culqui.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name= "cuenta")
public class Cuenta {
    @Id
    private String numeroCuenta;
    private String saldo;
    private String tipoCuenta;
    private String clienteId;
}
