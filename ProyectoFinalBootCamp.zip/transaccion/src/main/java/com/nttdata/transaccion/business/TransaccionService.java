package com.nttdata.transaccion.business;

import com.nttdata.transaccion.model.TransaccionRequest;
import com.nttdata.transaccion.model.TransaccionResponse;

import java.util.List;

public interface TransaccionService {

    public TransaccionResponse registrarDeposito(TransaccionRequest transaccionRequest);

    public TransaccionResponse registrarRetiro(TransaccionRequest transaccionRequest);

    public TransaccionResponse registrarTransferencia(TransaccionRequest transaccionRequest);

    public List<TransaccionResponse> listTransaccion();

}
