package com.nttdata.transaccion.model.entity;

import lombok.Data;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Document(collection = "Transaccion")
public class Transaccion {
    @Id
    private String id;
    private String TipoDeTransaccion;
    private BigDecimal Monto;
    private String Fecha;
    private String CuentaOrigen;
    private String CuentaDestino;
}
