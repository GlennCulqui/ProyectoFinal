package com.nttdata.transaccion.business;

import com.nttdata.transaccion.model.TransaccionRequest;
import com.nttdata.transaccion.model.TransaccionResponse;
import com.nttdata.transaccion.model.entity.Transaccion;
import org.springframework.stereotype.Component;

@Component
public class TransaccionMapper {


    public Transaccion getTransaccionDeTransaccionRequest(TransaccionRequest request){
        Transaccion entity   =   new Transaccion();
        entity.setId(request.getId());
        entity.setTipoDeTransaccion(request.getTipoDeTransaccion());
        entity.setMonto(request.getMonto());
        entity.setFecha(request.getFecha());
        entity.setCuentaOrigen(request.getCuentaOrigen());
        entity.setCuentaDestino(request.getCuentaDestino());
        return entity;
    }

    public TransaccionResponse getTransaccionResponseDeTransaccion(Transaccion entity){
        TransaccionResponse response    =   new TransaccionResponse();
        response.setId(entity.getId());
        response.setTipoDeTransaccion(entity.getTipoDeTransaccion());
        response.setMonto(entity.getMonto());
        response.setFecha(entity.getFecha());
        response.setCuentaOrigen(entity.getCuentaOrigen());
        response.setCuentaDestino(entity.getCuentaDestino());
        return response;
    }


}
