package com.nttdata.transaccion.business;

import com.nttdata.transaccion.model.TransaccionRequest;
import com.nttdata.transaccion.model.TransaccionResponse;
import com.nttdata.transaccion.repository.TransaccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransaccionServiceImp implements TransaccionService {

    @Autowired
    TransaccionRepository transaccionRepository;

    @Autowired
    TransaccionMapper transaccionMapper;

    @Override
    public TransaccionResponse registrarDeposito(TransaccionRequest transaccionRequest) {
        return transaccionMapper.getTransaccionResponseDeTransaccion(transaccionRepository
                .save(transaccionMapper.getTransaccionDeTransaccionRequest(transaccionRequest)));
    }
    @Override
    public TransaccionResponse registrarRetiro(TransaccionRequest transaccionRequest) {
        return transaccionMapper.getTransaccionResponseDeTransaccion(transaccionRepository
                .save(transaccionMapper.getTransaccionDeTransaccionRequest(transaccionRequest)));
    }

    @Override
    public TransaccionResponse registrarTransferencia(TransaccionRequest transaccionRequest) {
        return transaccionMapper.getTransaccionResponseDeTransaccion(transaccionRepository
                .save(transaccionMapper.getTransaccionDeTransaccionRequest(transaccionRequest)));
    }

    @Override
    public List<TransaccionResponse> listTransaccion( ) {
        return transaccionRepository.findAll().stream()
                .map(m->transaccionMapper.getTransaccionResponseDeTransaccion(m))
                .collect(Collectors.toList());
    }

}
