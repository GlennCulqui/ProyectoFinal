package com.nttdata.transaccion;

import com.nttdata.transaccion.api.TransaccionApiDelegate;
import com.nttdata.transaccion.business.TransaccionService;
import com.nttdata.transaccion.model.TransaccionRequest;
import com.nttdata.transaccion.model.TransaccionResponse;
import lombok.SneakyThrows;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransaccionDelegateImp implements TransaccionApiDelegate {

    @Autowired
    TransaccionService transaccionService;

    @Override
    public ResponseEntity<TransaccionResponse> registrarDeposito(TransaccionRequest transaccionRequest) {
        validarDepositoRetiro(transaccionRequest);
        transaccionRequest.setTipoDeTransaccion("Deposito");
        return ResponseEntity.ok(transaccionService.registrarDeposito(transaccionRequest));
    }

    @Override
    public ResponseEntity<TransaccionResponse> registrarRetiro(TransaccionRequest transaccionRequest) {
        validarDepositoRetiro(transaccionRequest);
        transaccionRequest.setTipoDeTransaccion("Retiro");
        return ResponseEntity.ok(transaccionService.registrarRetiro(transaccionRequest));
    }

    @Override
    public ResponseEntity<TransaccionResponse> registrarTransferencia(TransaccionRequest transaccionRequest){
        validarTransferencia(transaccionRequest);
        transaccionRequest.setTipoDeTransaccion("Transferencia");
        return ResponseEntity.ok(transaccionService.registrarTransferencia(transaccionRequest));
    }

    @Override
    public ResponseEntity<List<TransaccionResponse>> listTransaccion(){
        return ResponseEntity.ok(transaccionService.listTransaccion());
    }

    @SneakyThrows
    private void validarDepositoRetiro(TransaccionRequest transaccionRequest) {
        if (transaccionRequest.getCuentaOrigen() == null || transaccionRequest.getCuentaOrigen().isEmpty()) {
            throw new BadRequestException("la cuena origen es requerida");
        }
        if (transaccionRequest.getCuentaDestino() != null && !transaccionRequest.getCuentaDestino().isEmpty()) {
            throw new BadRequestException("la cuenta destino es requerida para operaciones de deposito y retiros");
        }
    }
    @SneakyThrows
    private void validarTransferencia(TransaccionRequest transaccionRequest){
        if(transaccionRequest.getCuentaOrigen()== null && transaccionRequest.getCuentaOrigen().isEmpty()){
            throw new BadRequestException("la cuenta origen es requerida para transferencias");
        }
        if(transaccionRequest.getCuentaDestino()==null && transaccionRequest.getCuentaDestino().isEmpty()){
            throw new BadRequestException("la cuenta destino es requerida para transferencias");
        }
    }

}
