package com.nttdata.transaccion.business;

public class TransaccionServiceImpTest {
}
