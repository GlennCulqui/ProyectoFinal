package com.nttdata.transaccion.business;

import com.nttdata.transaccion.model.TransaccionRequest;
import com.nttdata.transaccion.model.TransaccionResponse;
import com.nttdata.transaccion.model.entity.Transaccion;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class TransaccionMapperTest {

    private TransaccionMapper mapper= new TransaccionMapper();

    @Test
    @DisplayName("Test de ingreso de datos")
    void testGetTransaccionEntity(){

        TransaccionRequest request = new TransaccionRequest();
        request.setTipoDeTransaccion("Deposito");
        request.setMonto(new BigDecimal( "200"));
        request.setFecha("10/10/2024");
        request.setCuentaOrigen("456789");
        request.setCuentaDestino("987456");

        Transaccion result= mapper.getTransaccionDeTransaccionRequest(request);

        assertNotNull(result);
        assertEquals(request.getTipoDeTransaccion(),result.getTipoDeTransaccion());
        assertEquals(request.getMonto(), result.getMonto());
        assertNotNull(result.getFecha());
        assertEquals(request.getCuentaOrigen(),result.getCuentaOrigen());
        assertEquals(request.getCuentaDestino(), result.getCuentaDestino());
    }

    @Test
    @DisplayName("Test de obtencion de datos")
    void testgetTransaccionResponseDeTransaccion(){

        Transaccion response = new Transaccion();
        response.setTipoDeTransaccion("Deposito");
        response.setMonto(new BigDecimal( "200"));
        response.setFecha("10/10/2024");
        response.setCuentaOrigen("456789");
        response.setCuentaDestino("987456");

        TransaccionResponse result= mapper.getTransaccionResponseDeTransaccion(response);

        assertNotNull(result);
        assertEquals(response.getTipoDeTransaccion(),result.getTipoDeTransaccion());
        assertEquals(response.getMonto(), result.getMonto());
        assertNotNull(result.getFecha());
        assertEquals(response.getCuentaOrigen(),result.getCuentaOrigen());
        assertEquals(response.getCuentaDestino(), result.getCuentaDestino());
    }
}
