package com.nttdata.transaccion.repository;

import com.nttdata.transaccion.TransaccionDelegateImp;
import com.nttdata.transaccion.business.TransaccionService;
import com.nttdata.transaccion.business.TransaccionServiceImpTest;
import com.nttdata.transaccion.model.TransaccionRequest;
import com.nttdata.transaccion.model.TransaccionResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;


public class TransaccionDelegateImpTest {

    @InjectMocks
    private TransaccionDelegateImp transaccionDelegateImp;

    @Mock
    private TransaccionService transaccionService;

    @BeforeEach
    void setup(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Validacion Depositar exitosa")
    void testDepositarValidacion(){
        TransaccionRequest request = new TransaccionRequest();
        request.setMonto(new BigDecimal("2100"));
        request.setCuentaOrigen("000048751245");

        TransaccionResponse responseMock = new TransaccionResponse();
        responseMock.setMonto(request.getMonto());
        responseMock.setCuentaOrigen(request.getCuentaOrigen());
        responseMock.setTipoDeTransaccion("Deposito");

        when(transaccionService.registrarDeposito(any())).thenReturn(responseMock);

        ResponseEntity<TransaccionResponse> response = transaccionDelegateImp.registrarDeposito(request);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(responseMock, response.getBody());
        assertEquals("Deposito", response.getBody().getTipoDeTransaccion());
        verify(transaccionService).registrarDeposito(request);
    }

    @Test
    @DisplayName("Validacion Retirar exitosa")
    void testRetirarValidacion(){
        TransaccionRequest request = new TransaccionRequest();
        request.setMonto(new BigDecimal("250"));
        request.setCuentaOrigen("000007842145");

        TransaccionResponse responseMock = new TransaccionResponse();
        responseMock.setMonto(request.getMonto());
        responseMock.setCuentaOrigen(request.getCuentaOrigen());
        responseMock.setTipoDeTransaccion("Retiro");

        when(transaccionService.registrarRetiro(any())).thenReturn(responseMock);

        ResponseEntity<TransaccionResponse> response = transaccionDelegateImp.registrarRetiro(request);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(responseMock, response.getBody());
        assertEquals("Retiro", response.getBody().getTipoDeTransaccion());
        verify(transaccionService).registrarRetiro(request);
    }

    @Test
    @DisplayName("Validacion Transferencia exitosa")
    void testTransferenciaValidacion(){
        TransaccionRequest request = new TransaccionRequest();
        request.setMonto(new BigDecimal("250"));
        request.setCuentaOrigen("000007842100");
        request.setCuentaDestino("000007842145");

        TransaccionResponse responseMock = new TransaccionResponse();
        responseMock.setMonto(request.getMonto());
        responseMock.setCuentaOrigen(request.getCuentaOrigen());
        responseMock.setCuentaDestino(request.getCuentaDestino());
        responseMock.setTipoDeTransaccion("Transferencia");

        when(transaccionService.registrarTransferencia(any())).thenReturn(responseMock);

        ResponseEntity<TransaccionResponse> response = transaccionDelegateImp.registrarTransferencia(request);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(responseMock, response.getBody());
        assertEquals("Transferencia", response.getBody().getTipoDeTransaccion());
        verify(transaccionService).registrarTransferencia(request);
    }

    @Test
    @DisplayName("Validacion historial de transacciones exitosa")
    void testValidacionHistorial(){
        List<TransaccionResponse> transacciones = Arrays.asList(new TransaccionResponse(),new TransaccionResponse());
        when(transaccionService.listTransaccion()).thenReturn(transacciones);

        ResponseEntity<List<TransaccionResponse>> response = transaccionDelegateImp.listTransaccion();

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(2, response.getBody().size());
        verify(transaccionService).listTransaccion();
    }
}

